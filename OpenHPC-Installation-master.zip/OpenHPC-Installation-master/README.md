![OpenHPC Banner](https://repository-images.githubusercontent.com/156569976/556be300-746a-11e9-976f-abad06787c0f)

## OpenHPC Installation with PBS-Pro & Slurm job scheduler

This guide is a method for OpenHPC 1.3.5 installtion which is supported for CentOS 7.5.1804 with diskless compute nodes.

For more information please see at: https://openhpc.community/downloads/

If you have any question, pleace contact to me: bundit.b@hotmail.com

Enjoys!!!

```
Credits: 
1. Atip Peethong

   **OpenHPC with PBS Pro** 
   Guide: https://drive.google.com/file/d/1du_daXvQIHRGQ9RFUaCRtQyUk2BRrJ3A/view
   
   How to Install OpenHPC (part 1/3)(2018): https://www.youtube.com/watch?v=jTBEgdZLmYM
   How to Install OpenHPC (part 2/3)(2018): https://www.youtube.com/watch?v=S3ab6iNdXag
   How to Install OpenHPC (part 2/3)(2018): https://www.youtube.com/watch?v=otHHpdpv7Ps

   **OpenHPC with Slurm** 
   Guide: https://drive.google.com/file/d/1sUguvFtAVk62KYnMsivHepslxaDuyrzo/view
   
   How to Install OpenHPC Slurm (part 1/3)(2018): https://www.youtube.com/watch?v=7Am1WAqQl7M
   How to Install OpenHPC Slurm (part 2/3)(2018): https://www.youtube.com/watch?v=UfWeZ6k0KXM
   How to Install OpenHPC Slurm (part 3/3)(2018): https://www.youtube.com/watch?v=EwbSBq23RRk

2. Sombat Ketrat
3. https://github.com/dasandata/Open_HPC
```
